PDF Compressor v1 Setup (WINDOWS) v1 https://www.abort.lol
________________________________________________________
________________________________________________________
1
| NodeJS required
-> DOWNLOAD -> https://nodejs.org/en
| RESTART AFTER INSTALL
| Verify NodeJS is installed by using the command;
node -v

________________________________________________________
2
| Run the following command in cmd or powershell;
npm install express multer@1.4.4 dayjs chalk@4 open

________________________________________________________
3
| GhostScript is required
| https://ghostscript.com/releases/gsdnld.html
-> DOWNLOAD -> Ghostscript 10.05.1 for Windows (64 bit) Ghostscript AGPL Release 
| Verify GhostScript is installed using the command;
gswin64c -v

________________________________________________________
________________________________________________________
4
After that you're finished!
Every time you want to use the compressor just run "start-server.bat" to automate server startup
and easily view runtime / close the server when you're done

..or run the following command for manual startup (not recommended);
node server.js


extra;
Server is hosted on port:3000 by default
Make sure you allow NodeJS & GhostScript any asked permissions!
________________________________________________________
________________________________________________________


	         https://www.abort.lol


? Still encountering errors? -> https://github.com/zzzhya/pdf-compressor-v1/issues
created by zhya https://www.abort.lol - https://www.github.com/zzzhya