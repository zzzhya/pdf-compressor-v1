const { spawn, exec } = require('child_process');
const chalk = require('chalk');
const dayjs = require('dayjs');

console.clear();

const header = chalk.cyanBright(`
  ____  ____  _____                                                          
 |  _ \\|  _ \\|  ___|   ___ ___  _ __ ___  _ __  _ __ ___  ___ ___  ___  _ __ 
 | |_) | | | | |_     / __/ _ \\| '_ \` _ \\| '_ \\| '__/ _ \\/ __/ __|/ _ \\| '__|
 |  __/| |_| |  _|   | (_| (_) | | | | | | |_) | | |  __/\\__ \\__ \\ (_) | |   
 |_|   |____/|_|      \\___\\___/|_| |_| |_| .__/|_|  \\___||___/___/\\___/|_|   
                                         |_|  v1 created by zhya - abort.lol    
`);
const divider = chalk.gray('+'.repeat(78));
const startTime = new Date();

console.log(header);
console.log(chalk.green('- Starting PDF Compressor Server...'));
console.log(chalk.blue(`- Working directory: ${process.cwd()}`));
console.log(chalk.yellow(`- Started at: ${dayjs(startTime).format('YYYY-MM-DD HH:mm:ss')}`));
console.log(chalk.magenta('- Opening browser at http://localhost:3000'));
console.log(chalk.red('- Press Ctrl+C to stop the server'));
console.log(divider);

// Open browser (Windows)
exec('start http://localhost:3000');

// Start the server using spawn
const server = spawn('node', ['server.js'], { stdio: 'inherit' });

// Timer formatting
function formatTime(seconds) {
  const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

// Live uptime counter
let seconds = 0;
const interval = setInterval(() => {
  process.stdout.write(`\r🕒 Server Uptime: ${chalk.bold(formatTime(seconds++))} (Ctrl+C to stop) `);
}, 1000);

// Clean up on exit
server.on('exit', () => {
  clearInterval(interval);
  console.log('\n✅ Server has closed.');
});
