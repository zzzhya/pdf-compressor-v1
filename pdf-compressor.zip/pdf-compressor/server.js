const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static('public'));

// Ensure upload and output folders exist
const uploadDir = path.join(__dirname, 'uploads');
const compressedDir = path.join(__dirname, 'compressed');

if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
if (!fs.existsSync(compressedDir)) fs.mkdirSync(compressedDir);

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + '-' + file.originalname;
    cb(null, uniqueName);
  }
});

const upload = multer({ storage: storage });

// Upload route
app.post('/upload', upload.single('pdf'), async (req, res) => {
  const originalPath = req.file.path;
  const originalSize = req.file.size;
  const outputFilename = `${req.file.filename}-compressed.pdf`;
  const outputPath = path.join(compressedDir, outputFilename);

  // Ghostscript command (change gswin64c to gs if on Mac/Linux)
  const gsCommand = `gswin64c -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/ebook -dNOPAUSE -dQUIET -dBATCH -sOutputFile="${outputPath}" "${originalPath}"`;

  exec(gsCommand, (error, stdout, stderr) => {
    if (error) {
      console.error('Ghostscript compression failed:', error);
      return res.status(500).send('Compression failed');
    }

    // Get compressed size
    const compressedSize = fs.statSync(outputPath).size;

    // Clean up original uploaded file
    fs.unlinkSync(originalPath);

    // Send result
    res.json({
      originalSize,
      compressedSize,
      downloadUrl: `/download/${outputFilename}`
    });
  });
});

// Download route
app.get('/download/:filename', (req, res) => {
  const filePath = path.join(compressedDir, req.params.filename);
  if (fs.existsSync(filePath)) {
    res.download(filePath);
  } else {
    res.status(404).send('File not found');
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`PDF Compressor running at http://localhost:${PORT}`);
});
